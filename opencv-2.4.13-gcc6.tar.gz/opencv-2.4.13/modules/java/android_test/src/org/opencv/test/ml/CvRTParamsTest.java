package org.opencv.test.ml;

import org.opencv.ml.CvRTParams;
import org.opencv.test.OpenCVTestCase;

public class CvRTParamsTest extends OpenCVTestCase {

    public void testCvRTParams() {
        new CvRTParams();
    }

    public void testGet_calc_var_importance() {
        fail("Not yet implemented");
    }

    public void testGet_nactive_vars() {
        fail("Not yet implemented");
    }

    public void testSet_calc_var_importance() {
        fail("Not yet implemented");
    }

    public void testSet_nactive_vars() {
        fail("Not yet implemented");
    }

}
