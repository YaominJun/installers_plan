package org.opencv.test.ml;

import org.opencv.ml.CvSVM;
import org.opencv.test.OpenCVTestCase;

public class CvSVMTest extends OpenCVTestCase {

    public void testClear() {
        fail("Not yet implemented");
    }

    public void testCvSVM() {
        new CvSVM();
    }

    public void testCvSVMMatMat() {
        fail("Not yet implemented");
    }

    public void testCvSVMMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvSVMMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testCvSVMMatMatMatMatCvSVMParams() {
        fail("Not yet implemented");
    }

    public void testGet_support_vector_count() {
        fail("Not yet implemented");
    }

    public void testGet_var_count() {
        fail("Not yet implemented");
    }

    public void testPredictMat() {
        fail("Not yet implemented");
    }

    public void testPredictMatBoolean() {
        fail("Not yet implemented");
    }

    public void testTrain_autoMatMatMatMatCvSVMParams() {
        fail("Not yet implemented");
    }

    public void testTrain_autoMatMatMatMatCvSVMParamsInt() {
        fail("Not yet implemented");
    }

    public void testTrain_autoMatMatMatMatCvSVMParamsIntCvParamGrid() {
        fail("Not yet implemented");
    }

    public void testTrain_autoMatMatMatMatCvSVMParamsIntCvParamGridCvParamGrid() {
        fail("Not yet implemented");
    }

    public void testTrain_autoMatMatMatMatCvSVMParamsIntCvParamGridCvParamGridCvParamGrid() {
        fail("Not yet implemented");
    }

    public void testTrain_autoMatMatMatMatCvSVMParamsIntCvParamGridCvParamGridCvParamGridCvParamGrid() {
        fail("Not yet implemented");
    }

    public void testTrain_autoMatMatMatMatCvSVMParamsIntCvParamGridCvParamGridCvParamGridCvParamGridCvParamGrid() {
        fail("Not yet implemented");
    }

    public void testTrain_autoMatMatMatMatCvSVMParamsIntCvParamGridCvParamGridCvParamGridCvParamGridCvParamGridCvParamGrid() {
        fail("Not yet implemented");
    }

    public void testTrain_autoMatMatMatMatCvSVMParamsIntCvParamGridCvParamGridCvParamGridCvParamGridCvParamGridCvParamGridBoolean() {
        fail("Not yet implemented");
    }

    public void testTrainMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatMat() {
        fail("Not yet implemented");
    }

    public void testTrainMatMatMatMatCvSVMParams() {
        fail("Not yet implemented");
    }

}
