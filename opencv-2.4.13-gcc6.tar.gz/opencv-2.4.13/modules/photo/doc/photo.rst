********************************
photo. Computational Photography
********************************

.. highlight:: cpp

.. toctree::
    :maxdepth: 2

    inpainting
    denoising
