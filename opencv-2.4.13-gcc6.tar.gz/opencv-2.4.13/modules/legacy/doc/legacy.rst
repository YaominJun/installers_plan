********************************
legacy. Deprecated stuff
********************************

.. highlight:: cpp

.. toctree::
    :maxdepth: 2

    motion_analysis
    expectation_maximization
    histograms
    planar_subdivisions
    feature_detection_and_description
    common_interfaces_of_descriptor_extractors
    common_interfaces_of_generic_descriptor_matchers
