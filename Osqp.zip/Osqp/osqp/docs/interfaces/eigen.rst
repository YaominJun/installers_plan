.. _eigen_interface:

Eigen
======

The Eigen interface is documented `here <https://robotology.github.io/osqp-eigen/doxygen/doc/html/index.html>`_.
